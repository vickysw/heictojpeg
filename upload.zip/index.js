var async = require('async');
const AWS = require('aws-sdk')
const gm = require('gm').subClass({imageMagick: true});

var BUCKET_NAME = 'mmscity';
var BUCKET_NAME_CONVERT='mmscity-converted';
const awss3 = new AWS.S3({
  maxRetries: 0,
  region: 'us-east-1'
})

const root    = process.env['LAMBDA_TASK_ROOT'];
const path    = process.env['PATH'];
const libPath = process.env['PATH'];

// change the Lambda Runtime to use pre-built binary
process.env['PATH']            = `${root}/bin:${path}`;
process.env['LD_LIBRARY_PATH'] = `${root}/lib:${libPath}`;



exports.handler = (event, context) => {
  console.log(event);
  console.log(event.requestPayload);
  console.log(event.requestPayload.Records);
  console.log(event.requestPayload.Records[0].s3);
  const srcBucket = event.requestPayload.Records[0].s3.bucket.name;
  const srcKey = event.requestPayload.Records[0].s3.object.key;

  console.log(`Getting ${srcKey} from s3://${srcBucket}`)

  var n = srcKey.lastIndexOf('.');
var result = srcKey.substring(n + 1);
var strnewname=srcKey.replace(result,'jpg');

  console.log({
    Bucket: srcBucket,
    Key: srcKey
  });
console.log(result);
console.log(awss3);
//awss3.getObject({Bucket: srcBucket,Key: srcKey},function (error,response){

  console.log('----------------------');
  //console.log(error);
  //console.log(response);
  
  if(result=='heic' || result=='heif' || result=='HEIC' || result=='HEIF'){
    //console.log(response.Body)
    gm('https://'+srcBucket+'.s3.amazonaws.com/'+srcKey).setFormat('jpeg').toBuffer(function (err, buffer) {
              
      console.log(err)
      console.log(buffer)
      if(err){
        console.log(err);
          console.log('gm err responce')
      }else{
        
        var params = {
          Bucket: BUCKET_NAME_CONVERT,
          Key: strnewname,
          Body: buffer,
          ACL: 'public-read',
          ContentType: 'image/jpeg',
          
        };
        console.log(params)
        awss3.putObject(params, function(err, data) {
          if (err) {
            console.log(err);
            console.log('upload err responce')
          }
          console.log(data)
          console.log('done')
          
        });
      }
      
    });
  }else{
    console.log('out done')
  }
  

//})

  
}